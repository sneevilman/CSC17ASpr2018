#include <iostream>
using namespace std;
int main(int argc, char** argv) {
    
//    int num=678;                      //converts base 10 to base x
//    short base=16;
//    while(num%base>0){
//        cout<<num%base<<endl;
//        num/=base;
//    }
      
    
    { 
    int binary=0b101010111100,octal=05274,hex=0xABC,decimal=2748;
    cout<<"Binary  = "<<binary<<endl;
    cout<<"Octal   = "<<octal<<endl;
    cout<<"Hex     = "<<hex<<endl;
    cout<<"Decimal = "<<decimal<<endl;
     }cout<<endl;
    cout<<"678 base 8 does not exist."<<endl<<endl;
    {
    int binary=0b1010100110,octal=01246,hex=0x2A6,decimal=678;
    cout<<"Binary  = "<<binary<<endl;
    cout<<"Octal   = "<<octal<<endl;
    cout<<"Hex     = "<<hex<<endl;
    cout<<"Decimal = "<<decimal<<endl;
    }cout<<endl;
    {
    int binary=0b10010,octal=022,hex=0x12,decimal=18;
    cout<<"Binary  = "<<binary<<endl;
    cout<<"Octal   = "<<octal<<endl;
    cout<<"Hex     = "<<hex<<endl;
    cout<<"Decimal = "<<decimal<<endl;
    }
    return 0;
}

